<?php
// Heading
$_['heading_title'] = 'eroticshop theme';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified the eroticshop theme!';
$_['text_edit'] = 'Edit eroticshop Theme';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the eroticshop theme!';
