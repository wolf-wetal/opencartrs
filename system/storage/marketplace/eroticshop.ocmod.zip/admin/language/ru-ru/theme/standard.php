<?php
// Heading
$_['heading_title'] = 'eroticshop theme';

// Text
$_['text_extension'] = 'Расширения';
$_['text_success'] = 'Успех: вы изменили тему эротического магазина!';
$_['text_edit'] = 'Изменить тему эротического магазина';

// Entry
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'Внимание: у вас нет разрешения на изменение темы эротического магазина!';
